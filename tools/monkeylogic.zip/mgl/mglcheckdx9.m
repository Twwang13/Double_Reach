function tf = mglcheckdx9()

tf = checkdx9;

end