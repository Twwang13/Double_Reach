function mglcreateplaybackscreen(subjectscreensize,rect,color)

mdqmex(42, subjectscreensize, rect, color);


end
