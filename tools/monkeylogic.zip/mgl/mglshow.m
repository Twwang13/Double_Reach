function mglshow(id)

mglactivategraphic([0 id],[0 1]);
mglrendergraphic;
mglpresent;
