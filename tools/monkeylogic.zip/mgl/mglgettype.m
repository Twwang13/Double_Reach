function type = mglgettype(id)
%   id - object ids returned from addbitmap, addmovie, etc.
%
%   May 4, 2016     Written by Jaewon Hwang (jaewon.hwang@hotmail.com)

type = mdqmex(21,id);
