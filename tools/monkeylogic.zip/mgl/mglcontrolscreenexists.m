function result = mglcontrolscreenexists()

result = mdqmex(23);
