monitor = GetMonitorPositions;
nmonitor = size(monitor,1);
rect = zeros(nmonitor,4);

for m=1:nmonitor
    h = figure;
    text(0,0,sprintf('%d',m));
    set(gca,'XLim',[-1 1], 'YLim',[-1 1]);
    set(h,'position',monitor(m,:));

    rect(m,:) = mglgetadapterrect(m);
end

sortrows(rect) == sortrows(Pos2Rect(monitor))
