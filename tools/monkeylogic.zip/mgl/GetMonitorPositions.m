function position = GetMonitorPositions()
%position = GetMonitorPositions()
%   position - [left bottom width height]
%
%   This function returns the sizes of all monitor screens in MATLAB
%   coordinates. The sizes may not be identical to the screen resolutions
%   that Windows reports in high DPI settings.  Also the row order of the
%   position matrix does not correspond to the DirectX device number or
%   Windows screen number.
%
%   This function fixes the bug of get(0,'MonitorPositions') in R2015aSP1
%   or earlier.
%
%   May 4, 2016     Written by Jaewon Hwang (jaewon.hwang@hotmail.com)

mglgetadaptercount;  % make MATLAB aware of DPI

position = get(0,'MonitorPositions');

if verLessThan('matlab','8.4')
    screensize = get(0,'ScreenSize');
    position(:,3:4) = position(:,3:4) - position(:,1:2) + 1;
    position(:,2) = screensize(4) - position(:,4) - position(:,2) + 2;
elseif verLessThan('matlab','8.6')
    screensize = get(0,'ScreenSize');
    DPI_ratio = mglgetadapterdisplaymode(1) / screensize(3);
    if 1 < DPI_ratio
        position(:,1) = position(:,1) + min(position(:,1)) - 1;
        position(:,2) = position(:,2) + max(sum(position(:,[2 4]),2)) - screensize(4);
    end
end
