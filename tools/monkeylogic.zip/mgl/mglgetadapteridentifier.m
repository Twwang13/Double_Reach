function info = mglgetadapteridentifier()
%info = mglgetadapteridentifier()
%
%   May 4, 2016     Written by Jaewon Hwang (jaewon.hwang@hotmail.com)

info = mdqmex(16);
