function alert_function(hook,MLConfig,TrialRecord)

switch hook
    case 'task_start'
        
    case 'block_start'
        
    case 'trial_start'
        
    case 'trial_end'
        
    case 'block_end'
        
    case 'task_end'
        
end

end
