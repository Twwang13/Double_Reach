pic = 1;
mov = 2;

ML_Benchmark = true;
ML_BenchmarkData = zeros(5000,2);
varargout{1} = cell(2,2);

for m=1:2
    dashboard(1,sprintf('Testing the screen flipping latency... (Pass %d/2)',m));
    
    ML_BenchMarkSampleCount = 1;
    ML_BenchMarkFrameCount = 1;
    time_of_flip = toggleobject(pic, 'status', 'on');
    idle(1000);
    toggleobject(pic, 'status', 'off');
    ML_BenchmarkData(1,1) = time_of_flip;
    ML_BenchmarkData(1,2) = time_of_flip;
    varargout{1}{1,m} = { ML_BenchmarkData(1:ML_BenchMarkSampleCount,1), ML_BenchmarkData(1:ML_BenchMarkFrameCount,2) };

    ML_BenchMarkSampleCount = 1;
    ML_BenchMarkFrameCount = 1;
    time_of_flip = toggleobject(mov, 'status', 'on');
    idle(1000);
    toggleobject(mov, 'status', 'off');
    ML_BenchmarkData(1,1) = time_of_flip;
    ML_BenchmarkData(1,2) = time_of_flip;
    varargout{1}{2,m} = { ML_BenchmarkData(1:ML_BenchMarkSampleCount,1), ML_BenchmarkData(1:ML_BenchMarkFrameCount,2) };
end
