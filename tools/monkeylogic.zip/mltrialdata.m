classdef mltrialdata < handle
    properties
        Trial
        Block
        TrialWithinBlock
        Condition
        AbsoluteTrialStartTime
        TrialDateTime
        TrialError
        BehavioralCodes
        AnalogData
        ReactionTime
        ObjectStatusRecord
        RewardRecord
        UserVars
        VariableChanges
        TaskObject
        CycleRate
    end
    properties (Constant = true)
        Ver = 1.0;
    end
    properties (Transient = true, Hidden = true)
        InterTrialInterval
        UserMessage
        NewEyeTransform
    end
    
    methods
        function export_to_file(obj,filename,varname)
            if ~exist('varname','var'), varname = sprintf('Trial%d',obj.Trial); end
            try
                [~,~,e] = fileparts(filename);
                switch lower(e)
                    case '.bhv2', fid = mlbhv2(filename,'a');
                    otherwise, fid = mlhdf5(filename,'a');
                end
                fid.write(obj,varname);
                close(fid);
            catch err
                if exist('fid','var'), close(fid); end
                rethrow(err);
            end
        end            
    end
end
