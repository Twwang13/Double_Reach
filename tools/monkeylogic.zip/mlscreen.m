classdef mlscreen < handle
    properties (SetAccess = protected)
        SubjectScreenRect
        Xsize
        Ysize
        SubjectScreenAspectRatio
        SubjectScreenFullSize
        SubjectScreenHalfSize
        DPI_ratio
        RefreshRate
        FrameLength
        
        BackgroundColor
        PixelsPerDegree
         
        PhotodiodeWhite
        PhotodiodeBlack
        EyeTracer
        JoystickCursor
        TouchCursor
        DashBoard
        ButtonLabel
        ButtonPressed
        ButtonReleased
        EscapeRequested
        TTL
        Reward
        RewardCount
        RewardDuration
        Stimulation
    end
    
    methods
        function obj = mlscreen(MLConfig)
            if exist('MLConfig','var') && isa(MLConfig,'mlconfig'), create(obj,MLConfig); end
        end
        function delete(obj), destroy(obj); end
        function destroy(obj)
            try
                if ~isempty(obj.SubjectScreenRect)
                    mgldestroycontrolscreen;
                    mgldestroysubjectscreen;
                end
            catch
                % do nothing
            end
        end
        
        function create(obj,MLConfig)
            mglcreatesubjectscreen(MLConfig.SubjectScreenDevice,MLConfig.SubjectScreenBackground,MLConfig.FallbackScreenRect,MLConfig.ForcedUseOfFallbackScreen);

            info = mglgetscreeninfo(1);
            obj.SubjectScreenRect = info.Rect;
            obj.Xsize = info.Rect(3) - info.Rect(1);
            obj.Ysize = info.Rect(4) - info.Rect(2);
            obj.SubjectScreenAspectRatio = obj.Xsize / obj.Ysize;
            obj.SubjectScreenFullSize = [obj.Xsize obj.Ysize];
            obj.SubjectScreenHalfSize = obj.SubjectScreenFullSize / 2;
            screensize = get(0,'ScreenSize');
            obj.DPI_ratio = mglgetadapterdisplaymode(1) / screensize(3);
            obj.RefreshRate = mglgetrefreshrate;
            obj.FrameLength = 1000 / obj.RefreshRate;
            
            obj.BackgroundColor = MLConfig.SubjectScreenBackground;
            obj.PixelsPerDegree = MLConfig.PixelsPerDegree(1);
        end
        
        function create_tracers(obj,MLConfig)
            DAQ = MLConfig.DAQ;
            if 1 < MLConfig.PhotoDiodeTrigger
                sz = MLConfig.PhotoDiodeTriggerSize;
                imdata = cat(3,ones(sz,sz),zeros(sz, sz, 3));
                obj.PhotodiodeBlack = mgladdbitmap(imdata,9);
                imdata = ones(sz, sz, 4);
                obj.PhotodiodeWhite = mgladdbitmap(imdata,9);
                half_sz = sz / 2;
                switch MLConfig.PhotoDiodeTrigger
                    case 2  % upper left
                        xori = half_sz;
                        yori = half_sz;
                    case 3  % upper right
                        xori = obj.Xsize - half_sz;
                        yori = half_sz;
                    case 4  % lower right
                        xori = obj.Xsize - half_sz;
                        yori = obj.Ysize - half_sz;
                    case 5  % lower left
                        xori = half_sz;
                        yori = obj.Ysize - half_sz;
                end
                mglsetorigin([obj.PhotodiodeBlack obj.PhotodiodeWhite],[xori yori]);
                mglactivategraphic([obj.PhotodiodeBlack obj.PhotodiodeWhite],[true false]);
            end

            switch lower(MLConfig.EyeTracerShape)
                case 'line'
                    obj.EyeTracer = mgladdline(MLConfig.EyeTracerColor,50);
                case {'circle','square'}
                    obj.EyeTracer = load_cursor('',MLConfig.EyeTracerShape,MLConfig.EyeTracerColor,MLConfig.EyeTracerSize,10);
            end
            obj.JoystickCursor(1) = load_cursor(MLConfig.JoystickCursorImage,MLConfig.JoystickCursorShape,MLConfig.JoystickCursorColor,MLConfig.JoystickCursorSize,9);
            obj.JoystickCursor(2) = load_cursor(MLConfig.JoystickCursorImage,MLConfig.JoystickCursorShape,MLConfig.JoystickCursorColor,MLConfig.JoystickCursorSize,10);

            obj.TouchCursor = load_cursor(MLConfig.TouchCursorImage,MLConfig.TouchCursorShape,MLConfig.TouchCursorColor,MLConfig.TouchCursorSize,10);

            obj.DashBoard = [mgladdtext('',12) mgladdtext('',12) mgladdtext('',12)];
            mglsetorigin(obj.DashBoard(1),[20 20]);
            mglsetorigin(obj.DashBoard(2),[20 40]);
            mglsetorigin(obj.DashBoard(3),[20 60]);

            load('mlimagedata.mat','green_pressed','green_released','red_pressed','red_released','reward_image','stimulation_triggered','ttl_triggered');
            ControlScreenRect = mglgetcontrolscreenrect();
            ControlScreenSize = ControlScreenRect(3:4) - ControlScreenRect(1:2);

            by = ControlScreenSize(2)-30;
            nbutton = DAQ.nButton;
            obj.ButtonLabel = NaN(1,sum(nbutton));
            obj.ButtonPressed = NaN(1,sum(nbutton));
            obj.ButtonReleased = NaN(1,sum(nbutton));
            for m=1:sum(nbutton)
                obj.ButtonLabel(m) = mgladdtext(sprintf('%d',m),12);
                mglsetproperty(obj.ButtonLabel(m),'halign',2);
                if nbutton(1) < m
                    obj.ButtonPressed(m) = mgladdbitmap(red_pressed,12);
                    obj.ButtonReleased(m) = mgladdbitmap(red_released,12);
                else
                    obj.ButtonPressed(m) = mgladdbitmap(green_pressed,12);
                    obj.ButtonReleased(m) = mgladdbitmap(green_released,12);
                end

                bx = 40 + (m-1)*40;
                mglsetorigin([obj.ButtonLabel(m) obj.ButtonPressed(m) obj.ButtonReleased(m)], [bx by-30; bx by; bx by]);
            end
            
            obj.EscapeRequested = mgladdtext('Escape',12);
            mglsetorigin(obj.EscapeRequested, [ControlScreenSize(1)-30 by]);
            mglsetproperty(obj.EscapeRequested,'halign',3,'valign',2);

            by = by-50;
            nttl = DAQ.nTTL;
            obj.TTL = NaN(2,sum(nttl));
            for m=1:sum(nttl)
                obj.TTL(1,m) = mgladdtext(sprintf('%d',m),12);
                mglsetproperty(obj.TTL(1,m),'halign',2);
                obj.TTL(2,m) = mgladdbitmap(ttl_triggered,12);

                bx = 40 + (m-1)*40;
                mglsetorigin(obj.TTL(:,m), [bx by-30; bx by]);
            end
            
            obj.Reward = mgladdbitmap(reward_image,12);
            obj.RewardCount = mgladdtext('0',12);
            obj.RewardDuration = mgladdtext('0',12);
            mglsetproperty(obj.RewardCount,'halign',2);
            mglsetproperty(obj.RewardDuration,'halign',3);
            mglsetorigin([obj.Reward obj.RewardCount obj.RewardDuration], [ControlScreenSize(1)-41 by; ControlScreenSize(1)-41 by-30; ControlScreenSize(1)-70 by-5]);

            by = by-50;
            nstimulation = DAQ.nStimulation;
            obj.Stimulation = NaN(2,sum(nstimulation));
            for m=1:sum(nstimulation)
                obj.Stimulation(1,m) = mgladdtext(sprintf('%d',m),12);
                mglsetproperty(obj.Stimulation(1,m),'halign',2);
                obj.Stimulation(2,m) = mgladdbitmap(stimulation_triggered,12);

                bx = 40 + (m-1)*40;
                mglsetorigin(obj.Stimulation(:,m), [bx by-30; bx by]);
            end
            
            mglactivategraphic([obj.EyeTracer obj.JoystickCursor obj.TouchCursor obj.DashBoard ...
                obj.ButtonLabel obj.ButtonPressed obj.ButtonReleased obj.EscapeRequested ...
                obj.TTL(:)' obj.Reward obj.RewardCount obj.Stimulation(:)'], false);
        end
    end
end
