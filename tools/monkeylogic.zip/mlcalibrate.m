classdef mlcalibrate < handle
%MLCALIBRATE provides following calibration functions
% sig2deg(voltage,offset): convert voltages (n-by-2) to degrees. Each
%                          calibration method should provide this function.
% deg2pix(deg)           : convert degrees to subject screen coordinates.
% sig2pix(voltage,offset): concatenation of sig2deg and deg2pix
%
% subject2deg(xy): convert screen coordinates to degrees. Not signal dependent
% control2deg(xy): convert coordinates on the control screen to degrees.
%                  This function is not signal-dependent, but need to call
%                  update_control_screen_geometry() whenever the zoom level
%                  of the control screen changes.
% control2pix(xy): convert coordinates on the control screen to coordinates
%                  on the subject screen.
%
% translate(deg): move the origin of the transformation matrix
% rotate(theta) : rotate the transformation space. Currently works with 2-D
%                 spatial transformation method only
%
%   Mar 12, 2017    Written by Jaewon Hwang (jaewon.hwang@nih.gov, jaewon.hwang@hotmail.com)

    properties (SetAccess = protected)
        sig2deg
        TransformMatrix   % Transform Matrix: cell(1,3)
    end
    properties (SetAccess = protected, Hidden = true)
        calmethod   % Calibration Method: 1-3
        ppd         % PixelsPerDegree
        ssrc        % SubjectScreenRect
        ssfull      % SubjectScreenFullSize
        sshalf      % SubjectScreenHalfSize
        aspectratio % SubjectScreenAspectRatio
        cspos       % ControlScreenPosition
        c2s_ratio   % Control2SubjectRatio
    end

    methods (Access = protected)
        function xy = raw_signal(obj,xy,offset)  % Calibration method 1: Raw signal
            n = size(xy,1);
            xy = xy - repmat(obj.TransformMatrix{1}.offset + offset,n,1);
        end
        function xy = origin_gain(obj,xy,offset)  % Calibration method 2: Origin-Gain
            n = size(xy,1);
            xy = (xy - repmat(obj.TransformMatrix{2}.origin + offset./obj.TransformMatrix{2}.gain,n,1)) .* repmat(obj.TransformMatrix{2}.gain,n,1);
        end
        function xy = spatial_transform(obj,xy,offset)  % Calibration method 3: 2-D Spatial Transformation
            n = size(xy,1);
            xy = tformfwd(obj.TransformMatrix{3},xy) - repmat(offset,n,1);
        end
    end        
    
    methods
        function obj = mlcalibrate(sig_type,MLConfig)
            switch sig_type
                case {1,'eye'}
                    obj.TransformMatrix = MLConfig.EyeTransform;
                    obj.calmethod = MLConfig.EyeCalibration;
                case {2,'joy'}
                    obj.TransformMatrix = MLConfig.JoystickTransform;
                    obj.calmethod = MLConfig.JoystickCalibration;
            end
            if ~isfield(obj.TransformMatrix{1},'offset'), obj.TransformMatrix{1}.offset = [0 0]; end
            obj.ppd = MLConfig.PixelsPerDegree;
            obj.ssrc = MLConfig.Screen.SubjectScreenRect;
            obj.ssfull = MLConfig.Screen.SubjectScreenFullSize;
            obj.sshalf = MLConfig.Screen.SubjectScreenHalfSize;
            obj.aspectratio = MLConfig.Screen.SubjectScreenAspectRatio;

            obj.update_controlscreen_geometry();

            switch obj.calmethod
                case 2, obj.sig2deg = @obj.origin_gain;
                case 3, obj.sig2deg = @obj.spatial_transform;
                otherwise, obj.sig2deg = @obj.raw_signal;
            end
        end
        function rc = update_controlscreen_geometry(obj)
            if ~mglcontrolscreenexists(), rc = []; return, end
            info = mglgetscreeninfo(2);
            rc = info.Rect;
            obj.cspos = rc;
            sz = rc(3:4) - rc(1:2);
            zoom = info.Zoom;
            if sz(1) < obj.aspectratio * sz(2)
                obj.cspos(3) = sz(1) * zoom;
                obj.cspos(4) = sz(1) * zoom / obj.aspectratio;
            else
                obj.cspos(3) = sz(2) * zoom * obj.aspectratio;
                obj.cspos(4) = sz(2) * zoom;
            end
            obj.cspos(1:2) = obj.cspos(1:2) + (sz-obj.cspos(3:4)) / 2;
            obj.c2s_ratio = obj.ssfull ./ obj.cspos(3:4);
        end            
        
        function xy = deg2pix(obj,xy)
            n = size(xy,1);
            xy = xy .* repmat(obj.ppd,n,1) + repmat(obj.sshalf,n,1);
        end
        function xy = sig2pix(obj,xy,offset)
            xy = obj.deg2pix(obj.sig2deg(xy,offset));
        end
        function xy = subject2deg(obj,xy)
            n = size(xy,1);
            xy = (xy - repmat(obj.ssrc(1:2) + obj.sshalf,n,1)) ./ repmat(obj.ppd,n,1);
        end
        function xy = control2deg(obj,xy)
            n = size(xy,1);
            xy = (xy - repmat(obj.cspos(1:2) + obj.sshalf ./ obj.c2s_ratio,n,1)) .* repmat(obj.c2s_ratio ./ obj.ppd,n,1);
        end
        function xy = control2pix(obj,xy)
            n = size(xy,1);
            xy = (xy - repmat(obj.cspos(1:2),n,1)) .* repmat(obj.c2s_ratio,n,1);
        end
        
        function tform = translate(obj,offset)
            if any(offset)
                switch obj.calmethod
                    case 1
                        obj.TransformMatrix{1}.offset = obj.TransformMatrix{1}.offset + offset; 
                    case 2
                        obj.TransformMatrix{2}.origin = obj.TransformMatrix{2}.origin + offset./obj.TransformMatrix{2}.gain;
                    case 3
                        ml_tri = [0 0; 1 0; 0 1];

                        % maketform() is provided by Image Processing Toolbox and is no longer MATLAB-recommended
                        % future versions should avoid using this function
                        ml_trans = maketform('affine', ml_tri, ml_tri - repmat(offset,3,1)); %#ok<MTFA2>
                        ml_tform = copyfield(obj, [], obj.TransformMatrix{3}, {'ndims_in','ndims_out','forward_fcn','inverse_fcn','tdata'});
                        ml_comp = maketform('composite', ml_trans, ml_tform);
                        ml_cpi = [0 0; 1 0; 0 1; 1 1];
                        ml_cpo = tformfwd(ml_comp, ml_cpi);

                        % cp2tform is not recommended by MATLAB in the future. Use fitgeotrans() instead.
                        obj.TransformMatrix{3} = copyfield(obj, obj.TransformMatrix{3}, cp2tform(ml_cpi,ml_cpo,'projective')); %#ok<DCPTF>
                end
            end
            tform = obj.TransformMatrix{obj.calmethod};
        end
        function tform = rotate(obj,theta)
            if 0~=theta
                switch obj.calmethod
                    case 3
                        % counterclockwise transform (in deg)
                        matrix_rotation = [cosd(theta) sind(theta) 0; -sind(theta) cosd(theta) 0; 0 0 1];
                        
                        % maketform() is deprecated, but jTform requires this form for below jTform is a persistent variable, so this should stay updated
                        tform_rotation = affline2d(matrix_rotation);
                        obj.TransformMatrix{3} = maketform('composite', [tform_rotation,obj.TransformMatrix{3}]);

                    otherwise
                        error('This method does not support the rotation');
                end
            end
            tform = obj.TransformMatrix{obj.calmethod};
        end
    end
    
    methods (Hidden = true)
        function update_transform_matrix(obj,tform)
            if 1<obj.calmethod
                obj.TransformMatrix{obj.calmethod} = tform;
            end
        end
        function dest = copyfield(~,dest,src,field)
            if ~exist('field','var') || isempty(field), field = fieldnames(src); end
            for m=1:length(field), dest.(field{m}) = src.(field{m}); end
        end
    end
end
