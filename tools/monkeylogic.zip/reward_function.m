function reward_function(Duration, varargin)

persistent Reward Channel Polarity RewardOn RewardOff
persistent NumReward PauseTime TriggerVal

% This is an example of how to customize this reward function. Let's say
% that we have a reward device that can deliver 4 different fluid types.
% The flow of the fluids is regulated by 4 solenoid valves, which are
% controled via 4 digital output lines. We want to be able to select the
% fluid type when we call goodmonkey().
% 
% First, we need to assign 4 digital lines to "Reward" in the main menu.
% (Yes, you can choose multiple lines for "Reward" now.) Then, declare a
% MATLAB variable in this script (to store the selected fluid type) and
% rewrite the reward_on() and reward_off() functions to utilize this new
% variable, like the following.
%
%	FluidType = 1;  % fluid type: [1 2 3 4]
% 
%   function reward_on()
%       putvalue(Reward, 2^(FluidType-1));  % This converts [1 2 3 4] to [1 2 4 8], which correspond to the digital line 1 to 4;
%   end
%   function reward_off()
%       putvalue(Reward, 0);
%   end
%
% Then, to change the fluid type, we can call goodmonkey() like this.
%
%   goodmonkey(50, 'FluidType',3, 'NumReward',2, 'PauseTime',300);  % deliver Fluid 3 for 50 msec twice at 300-ms intervals.


% Define user variables below. To change their values, call goodmonkey()
% like the following.
%
%   goodmonkey(DURATION, 'VARIABLE_NAME1',NEW_VALUE1, 'VARIABLE_NAME2',NEW_VALUE2);
%   or goodmonkey(DURATION, 'eval','VARIABLE_NAME1=NEW_VALUE1; VARIABLE_NAME2=NEW_VALUE2;');
%
% Unless the variables are defined as persistent, all changes are temporary.

% End of user variable definition


% Define what should be done to turn on and off your reward device in
% reward_on() and reward_off(), respectively. You can use your own
% variables you define above.
    function reward_on()
        switch class(Reward)
            case 'analogoutput', putsample(Reward,RewardOn);
            case 'digitalio', putvalue(Reward,RewardOn);
        end
    end
    function reward_off()
        switch class(Reward)
            case 'analogoutput', putsample(Reward,RewardOff);
            case 'digitalio', putvalue(Reward,RewardOff);
        end
    end
% End of custom reward functions


%
% The rest of the function below hardly needs modification.
%

if ischar(Duration), varargin = [Duration varargin]; Duration = 0; end
if Duration < 0
    DAQ = varargin{1};
    MLConfig = varargin{2};
    Reward = DAQ.Reward;
    if isempty(Reward), return, end
    Polarity = 1==MLConfig.RewardPolarity;
    r = MLConfig.RewardFuncArgs;
    NumReward = r.NumReward;
    PauseTime = r.PauseTime;
    TriggerVal = r.TriggerVal;
    eval(r.Custom);
    switch class(Reward)
        case 'analogoutput'
            Channel = strcmp(Reward.Channel.ChannelName,'Reward');
            RewardOn = zeros(1,length(Reward.Channel));
            RewardOff = RewardOn;
            RewardOn(Channel) = TriggerVal * Polarity;
            RewardOff(Channel) = TriggerVal * ~Polarity;
        case 'digitalio'
            RewardOn = Polarity;
            RewardOff = ~Polarity;
    end
    return;
end

ML_WarmingUp = false;
code = [];
if ~isempty(varargin);
    nargs = length(varargin);
    if mod(nargs,2), error('goodmonkey() requires all arguments beyond the first to come in parameter/value pairs'); end
    for m = 1:2:nargs
        val = varargin{m+1};
        switch lower(varargin{m});
            case 'eventmarker', code = val;
            case 'numreward', NumReward = val;
            case 'pausetime', PauseTime = val;
            case 'eval', eval(val);
            case 'triggerval', TriggerVal = val;
            case 'duration', Duration = val;
            otherwise, eval(sprintf('%s=%f;',varargin{m},val));
        end
    end
    if isa(Reward,'analogoutput')
        RewardOn(Channel) = TriggerVal * Polarity;
        RewardOff(Channel) = TriggerVal * ~Polarity;
    end
end
switch length(code)
    case 0, code = NaN(1,NumReward);
    case 1, code = repmat(code,1,NumReward);
    otherwise, code(end+1:NumReward) = code(end);
end

inter_reward_interval = PauseTime / 1000;
for m = 1:NumReward
    if ML_WarmingUp, reward_off(); else reward_on(); end %#ok<UNRCH>
    mdqmex(99,Duration,code(m));
    reward_off();
    mdqmex(100);
    if m < NumReward, elapsed = tic; while toc(elapsed) < inter_reward_interval, end, end
end

end
