classdef mltaskobject < matlab.mixin.Copyable
    properties (SetAccess = protected)
        ID
        Modality
    end
    properties
        Status
        Position
    end
    properties (SetAccess = protected)
        ScreenPosition
        Info
        MoreInfo
    end
    properties (SetAccess = protected, Hidden)
        PixelsPerDegree
        SubjectScreenHalfSize
        DestroyObject
    end
    methods
        function obj = mltaskobject(taskobj,MLConfig,TrialRecord)
            clear(obj);
            if ~exist('taskobj','var'), return; end
            if isa(taskobj,'mltaskobject')
                obj = copy(taskobj);
            else
                obj.PixelsPerDegree = MLConfig.PixelsPerDegree;
                obj.SubjectScreenHalfSize = MLConfig.Screen.SubjectScreenHalfSize;
                if ~exist('TrialRecord','var') || ~isa(TrialRecord,'mltrialrecord'), TrialRecord = mltrialrecord; TrialRecord = TrialRecord.simulate_1st_trial; end
                if ischar(taskobj), taskobj = {taskobj}; end
                if iscell(taskobj), taskobj = MLConfig.MLConditions.parse_object(taskobj); end
                if isfield(taskobj,'Attribute'), createobj(obj,taskobj,MLConfig,TrialRecord); else createobj_from_struct(obj,taskobj,MLConfig,TrialRecord); end
                obj.DestroyObject = true;
            end
            TrialRecord.set_stimulus_info(obj);
        end
        function delete(obj), clear(obj); end
        function clear(obj)
            if obj.DestroyObject
                for m=1:length(obj.ID)
                    switch obj.Modality(m)
                        case {1,2}, try mgldestroygraphic(obj.ID(m)); catch, end
                        case 3, try mgldestroysound(obj.ID(m)); catch, end
                    end
                end
            end
            obj.ID = [];
            obj.Modality = [];
            obj.Status = false;
            obj.Position = [];
            obj.ScreenPosition = [];
            obj.Info = struct;
            obj.MoreInfo = {};
            obj.DestroyObject = false;
        end
        function val = length(obj), val = length(obj.ID); end
        function val = size(obj), val = size(obj.ID); end
        
        function val = get_ScreenPosition(obj,Position)
            n = size(Position,1);
            val = round(Position .* repmat(obj.PixelsPerDegree,n,1)) + repmat(obj.SubjectScreenHalfSize,n,1);
        end
        
        function obj = subsasgn(obj,s,b)
            switch length(s)
                case 1, error('This type of assignment is not allowed.');
                case 2
                    switch s(1).type
                        case {'()','{}'}
                            if strcmp(s(2).type,'.')
                                if isempty(s(1).subs{1})
                                    error('Index is not given');
                                else
                                    switch s(2).subs
                                        case 'Status', obj.Status(s(1).subs{1}) = b;
                                        case 'Position'
                                            obj.Position(s(1).subs{1},:) = b;
                                            obj.ScreenPosition(s(1).subs{1},:) = get_ScreenPosition(obj,b);
                                        otherwise, error('''%s'' is a read-only property',s(2).subs);
                                    end
                                end
                            end
                        case '.'
                            if strcmp(s(2).type,'()') || strcmp(s(2).type,'{}')
                                if isempty(s(2).subs{1})
                                    error('Index is not given');
                                else
                                    switch s(1).subs
                                        case 'Status', obj.Status(s(2).subs{1}) = b;
                                        case 'Position'
                                            obj.Position(s(2).subs{1},:) = b;
                                            obj.ScreenPosition(s(2).subs{1},:) = get_ScreenPosition(obj,b);
                                        otherwise, error('''%s'' is a read-only property',s(1).subs);
                                    end
                                end
                            end
                        otherwise
                            error('Unknown subsref type');
                    end
                otherwise
                    error('This type of assignment is not allowed.');
            end
        end
        
        function varargout = subsref(obj,s)
            switch length(s)
                case 1
                    switch s.type
                        case {'()','{}'}
                            if isempty(s.subs)
                                varargout{1} = [];
                            else
                                idx = s.subs{1};
                                varargout{1} = mltaskobject;
                                varargout{1}.ID = obj.ID(idx);
                                varargout{1}.Modality = obj.Modality(idx);
                                varargout{1}.Status = obj.Status(idx);
                                varargout{1}.Position = obj.Position(idx,:);
                                varargout{1}.ScreenPosition = obj.ScreenPosition(idx,:);
                                varargout{1}.Info = obj.Info(idx);
                                varargout{1}.MoreInfo = obj.MoreInfo(idx);
                                varargout{1}.PixelsPerDegree = obj.PixelsPerDegree;
                                varargout{1}.SubjectScreenHalfSize = obj.SubjectScreenHalfSize;
                                varargout{1}.DestroyObject = false;
                            end
                        case '.'
                            varargout{1} = obj.(s.subs);
                        otherwise
                            error('Unknown subsref type');
                    end
                case 2
                    switch s(1).type
                        case {'()','{}'}
                            if strcmp(s(2).type,'.')
                                if isempty(s(1).subs)
                                    varargout{1} = [];
                                else
                                    narr = length(s(1).subs{1});
                                    if 1==narr
                                        switch s(2).subs
                                            case 'MoreInfo', varargout(1) = obj.(s(2).subs)(s(1).subs{1});
                                            case {'Position','ScreenPosition'}, varargout{1} = obj.(s(2).subs)(s(1).subs{1},:);
                                            otherwise, varargout{1} = obj.(s(2).subs)(s(1).subs{1});
                                        end
                                    else
                                        varargout = cell(narr,1);
                                        for m=1:narr
                                            switch s(2).subs
                                                case 'MoreInfo', varargout(m) = obj.(s(2).subs)(s(1).subs{1}(m));
                                                case {'Position','ScreenPosition'}, varargout{m} = obj.(s(2).subs)(s(1).subs{1}(m),:);
                                                otherwise, varargout{m} = obj.(s(2).subs)(s(1).subs{1}(m));
                                            end
                                        end
                                    end
                                end
                            end
                        case '.'
                            switch s(2).type
                                case {'()','{}'}
                                    if isempty(s(2).subs)
                                        varargout{1} = [];
                                    else
                                        switch s(1).subs
                                            case 'MoreInfo', if 1==length(s(2).subs{1}), varargout{1} = obj.(s(1).subs){s(2).subs{1}}; else varargout{1} = obj.(s(1).subs)(s(2).subs{1}); end
                                            case {'Position','ScreenPosition'}, varargout{1} = obj.(s(1).subs)(s(2).subs{1},:);
                                            otherwise, varargout{1} = obj.(s(1).subs)(s(2).subs{1});
                                        end
                                    end
                                case '.'
                                    narr = length(obj);
                                    if 1==narr
                                        switch s(1).subs
                                            case 'Info', varargout{1} = obj.(s(1).subs)(1).(s(2).subs);
                                            case 'MoreInfo', varargout{1} = obj.(s(1).subs){1}.(s(2).subs);
                                        end
                                    else
                                        varargout{1} = cell(1,narr);
                                        switch s(1).subs
                                            case 'Info', for m=1:narr, varargout{1}{m} = obj.(s(1).subs)(m).(s(2).subs); end
                                            case 'MoreInfo', for m=1:narr, varargout{1}{m} = obj.(s(1).subs){m}.(s(2).subs); end
                                        end
                                    end
                            end
                        otherwise
                            error('Unknown subsref type');
                    end
                case 3
                    switch s(1).type
                        case {'()','{}'}
                            if '.'==s(2).type
                                narr = length(s(1).subs{1});
                                varargout = cell(1,narr);
                                switch s(2).subs
                                    case 'Info', for m=1:narr, varargout{m} = obj.(s(2).subs)(s(1).subs{1}(m)).(s(3).subs); end
                                    case 'MoreInfo', for m=1:narr, varargout{m} = obj.(s(2).subs){s(1).subs{1}(m)}.(s(3).subs); end
                                end
                            end
                        case '.'
                            if strcmp(s(2).type,'()') || strcmp(s(2).type,'{}')
                                narr = length(s(2).subs{1});
                                if 1==narr
                                    switch s(1).subs
                                        case 'Info', varargout{1} = obj.(s(1).subs)(s(2).subs{1}).(s(3).subs);
                                        case 'MoreInfo', varargout{1} = obj.(s(1).subs){s(2).subs{1}}.(s(3).subs);
                                    end
                                else                                    
                                    varargout{1} = cell(1,narr);
                                    switch s(1).subs
                                        case 'Info', for m=1:narr, varargout{1}{m} = obj.(s(1).subs)(s(2).subs{1}(m)).(s(3).subs); end
                                        case 'MoreInfo', for m=1:narr, varargout{1}{m} = obj.(s(1).subs){s(2).subs{1}(m)}.(s(3).subs); end
                                    end
                                end
                            end
                        otherwise
                            error('Unknown subsref type');
                    end
                case 4
                    switch s(1).type
                        case {'()','{}'}, varargout{1} = obj.(s(2).subs)(s(1).subs{1}).(s(3).subs){s(4).subs{1}};
                        case '.', varargout{1} = obj.(s(1).subs)(s(2).subs{1}).(s(3).subs){s(4).subs{1}};
                    end
                otherwise
                    error('Unknown subsref type');
            end
        end
    end
    
    methods (Access = protected)
        function cp = copyElement(obj)
            cp = copyElement@matlab.mixin.Copyable(obj);
            cp.DestroyObject = false;
        end
        
        function createobj_from_struct(obj,taskobj,MLConfig,TrialRecord)
            nobj = length(taskobj);
            obj.ID(1:nobj) = NaN;
            obj.Modality(1:nobj) = 0;
            obj.Status(1:nobj) = false;
            obj.Position(1:nobj,1:2) = NaN;
            obj.Info = taskobj;
            obj.MoreInfo(1:nobj) = cell(1,nobj);

            for m=1:nobj
                idx = m;
                o = taskobj(m);
                switch lower(o.Type)
                    case 'gen'
                        [~,n] = fileparts(o.Name);
                        if isfield(o,'Xpos'), x = o.Xpos; else x = 0; end
                        if isfield(o,'Ypos'), y = o.Ypos; else y = 0; end
                        info = [];
                        switch nargout(n)
                            case 2, [imdata,info] = feval(n,TrialRecord);
                            case 3, [imdata,x,y] = feval(n,TrialRecord);
                            case 4, [imdata,x,y,info] = feval(n,TrialRecord);
                            otherwise, imdata = feval(n,TrialRecord);
                        end
                        if ischar(imdata)
                            if 2~=exist(imdata,'file'), error('File from Gen doesn''t exist'); end
                            [~,~,e] = fileparts(imdata);
                            switch lower(e)
                                case {'.bmp','.gif','.jpg','.jpeg','.tif','.tiff','.png'}
                                    bits = mglimread(imdata);
                                    if 3==size(bits,3) && isfield(info,'Colorkey'), obj.ID(idx) = mgladdbitmap(bits,info.Colorkey); else obj.ID(idx) = mgladdbitmap(bits); end
                                    obj.Modality(idx) = 1;
                                    info = copyfield(obj,info,imfinfo(imdata));
                                    info.Size = mglgetproperty(obj.ID(idx),'size');
                                case {'.avi','.mpg','.mpeg'}
                                    obj.ID(idx) = mgladdmovie(imdata);
                                    obj.Modality(idx) = 2;
                                    info.Filename = imdata;
                                    info = copyfield(obj,info,mglgetproperty(obj.ID(idx),'info'));
                                otherwise
                                    error('Unknown file type from Gen');
                            end
                        else
                            info.Filename = '';
                            switch ndims(imdata)
                                case 2
                                    if isfield(info,'Colorkey'), obj.ID(idx) = mgladdbitmap(repmat(imdata,1,1,3),info.Colorkey); else obj.ID(idx) = mgladdbitmap(repmat(imdata,1,1,3)); end
                                    obj.Modality(idx) = 1;
                                    info.Size = mglgetproperty(obj.ID(idx),'size');
                                case 3,
                                    if 3==size(imdata,3) && isfield(info,'Colorkey'), obj.ID(idx) = mgladdbitmap(imdata,info.Colorkey); else obj.ID(idx) = mgladdbitmap(imdata); end
                                    obj.Modality(idx) = 1;
                                    info.Size = mglgetproperty(obj.ID(idx),'size');
                                case 4
                                    if isfield(info,'FramesPerSecond'), obj.ID(idx) = mgladdmovie(imdata,info.FramesPerSecond); else obj.ID(idx) = mgladdmovie(imdata,0.033333333333333333333333333333333); end
                                    obj.Modality(idx) = 2;
                                    info = copyfield(obj,info,mglgetproperty(obj.ID(idx),'info'));
                                otherwise, error('Image type from Gen cannot be determined');
                            end
                        end
                        obj.Position(idx,:) = [x y];
                        obj.MoreInfo{idx} = info;
                    case {'fix','dot'}
                        obj.ID(idx) = mgladdbitmap(load_cursor(MLConfig.FixationPointImage,MLConfig.FixationPointShape,MLConfig.FixationPointColor,MLConfig.PixelsPerDegree(1)*MLConfig.FixationPointDeg));
                        obj.Modality(idx) = 1;
                        obj.Position(idx,:) = [o.Xpos o.Ypos];
                        if isempty(MLConfig.FixationPointImage), obj.MoreInfo{idx}.Filename = ''; else obj.MoreInfo{idx} = imfinfo(MLConfig.FixationPointImage); end
                        obj.MoreInfo{idx}.Size = mglgetproperty(obj.ID(idx),'size');
                    case 'pic'
                        if isfield(o,'Xsize') && isfield(o,'Ysize'), imdata = imresize(mglimread(o.Name),[o.Ysize o.Xsize],'lanczos3'); else imdata = mglimread(o.Name); end
                        if 3==size(imdata,3) && isfield(o,'Colorkey'), obj.ID(idx) = mgladdbitmap(imdata,o.Colorkey); else obj.ID(idx) = mgladdbitmap(imdata); end
                        obj.Modality(idx) = 1;
                        obj.Position(idx,:) = [o.Xpos o.Ypos];
                        obj.MoreInfo{idx} = imfinfo(o.Name);
                        obj.MoreInfo{idx}.Size = mglgetproperty(obj.ID(idx),'size');
                    case 'crc'
                        obj.ID(idx) = mgladdbitmap(make_circle(MLConfig.PixelsPerDegree(1)*o.Radius,o.Color,o.FillFlag));
                        obj.Modality(idx) = 1;
                        obj.Position(idx,:) = [o.Xpos o.Ypos];
                        obj.MoreInfo{idx}.Filename = '';
                        obj.MoreInfo{idx}.Size = mglgetproperty(obj.ID(idx),'size');
                    case 'sqr'
                        obj.ID(idx) = mgladdbitmap(make_rectangle([o.Xsize o.Ysize]*MLConfig.PixelsPerDegree(1),o.Color,o.FillFlag));
                        obj.Modality(idx) = 1;
                        obj.Position(idx,:) = [o.Xpos o.Ypos];
                        obj.MoreInfo{idx}.Filename = '';
                        obj.MoreInfo{idx}.Size = mglgetproperty(obj.ID(idx),'size');
                    case 'mov'
                        obj.ID(idx) = mgladdmovie(o.Name);
                        obj.Modality(idx) = 2;
                        obj.Position(idx,:) = [o.Xpos o.Ypos];
                        obj.MoreInfo{idx}.Filename = o.Name;
                        obj.MoreInfo{idx} = copyfield(obj,obj.MoreInfo{idx},mglgetproperty(obj.ID(idx),'info'));
                    case 'snd'
                        if isfield(o,'Name') && ~isempty(o.Name)
                            if strcmpi(o.Name,'sin')
                                [y,fs] = load_waveform({'snd', o.Duration, o.Freq});
                                obj.MoreInfo{idx}.Filename = '';
                            else
                                [y,fs] = load_waveform({'snd', o.Name});
                                obj.MoreInfo{idx}.Filename = o.Name;
                            end
                        else
                            y = o.WaveForm;
                            fs = o.Freq;
                            obj.MoreInfo{idx}.Filename = '';
                        end
                        obj.ID(idx) = mgladdsound(y,fs);
                        obj.Modality(idx) = 3;
                        obj.MoreInfo{idx}.Duration = length(y)/fs;
                        obj.MoreInfo{idx}.Frequency = fs;
                    case 'stm'
                        obj.ID(idx) = o.OutputPort;
                        obj.Modality(idx) = 4;
                        if isfield(o,'Name') && ~isempty(o.Name)
                            [y,fs] = load_waveform(o.Name);
                            obj.MoreInfo{idx}.Filename = o.Name;
                        else
                            y = o.WaveForm;
                            fs = o.Freq;
                            obj.MoreInfo{idx}.Filename = '';
                        end
                        obj.MoreInfo{idx}.Channel = o.OutputPort;
                        obj.MoreInfo{idx}.Duration = length(y)/fs;
                        obj.MoreInfo{idx}.Frequency = fs;
                        ao = MLConfig.DAQ.Stimulation{o.OutputPort};
                        if isempty(ao)
                            if ~TrialRecord.SimulationMode, error('''Stimulation %d'' is not assigned',o.OutputPort); end
                        else
                            stop(ao);
                            actual_rate = setverify(ao,'SampleRate',fs);
                            if actual_rate~=fs, error('output frequency is %g kHz, instead of %g kHz',actual_rate/1000,fs/1000); end
                            ch = strcmp(ao.Channel.ChannelName,sprintf('Stimulation%d',o.OutputPort));
                            data = zeros(length(y),length(ao.Channel));
                            data(:,ch) = y;
                            if isfield(o,'Retriggering'), ao.RegenerationMode = o.Retriggering; else ao.RegenerationMode = 0; end
                            putdata(ao,data);
                            start(ao);
                        end
                    case 'ttl'
                        obj.ID(idx) = o.OutputPort;
                        obj.Modality(idx) = 5;
                        obj.MoreInfo{idx}.Filename = '';
                        obj.MoreInfo{idx}.Channel = o.OutputPort;
                        if isempty(MLConfig.DAQ.TTL{o.OutputPort}) && ~TrialRecord.SimulationMode, error('''TTL %d'' is not assigned',o.OutputPort); end
                end
            end
            obj.ScreenPosition = get_ScreenPosition(obj,obj.Position);
            visualobj = 1==obj.Modality | 2==obj.Modality;
            mglsetorigin(obj.ID(visualobj),obj.ScreenPosition(visualobj,:));
        end
        
        function createobj(obj,taskobj,MLConfig,TrialRecord)
            nobj = length(taskobj);
            obj.ID(1:nobj) = NaN;
            obj.Modality(1:nobj) = 0;
            obj.Status(1:nobj) = false;
            obj.Position(1:nobj,1:2) = NaN;
            obj.Info = taskobj;
            obj.MoreInfo(1:nobj) = cell(1,nobj);

            for m=1:nobj
                idx = m;
                a = taskobj(m).Attribute;
                switch lower(a{1})
                    case 'gen'
                        [~,n] = fileparts(a{2});
                        if 2<length(a), x = a{3}; y = a{4}; else x = 0; y = 0; end
                        info = [];
                        switch nargout(n)
                            case 2, [imdata,info] = feval(n,TrialRecord);
                            case 3, [imdata,x,y] = feval(n,TrialRecord);
                            case 4, [imdata,x,y,info] = feval(n,TrialRecord);
                            otherwise, imdata = feval(n,TrialRecord);
                        end
                        if ischar(imdata)
                            if 2~=exist(imdata,'file'), error('File from Gen doesn''t exist'); end
                            [~,~,e] = fileparts(imdata);
                            switch lower(e)
                                case {'.bmp','.gif','.jpg','.jpeg','.tif','.tiff','.png'}
                                    bits = mglimread(imdata);
                                    if 3==size(bits,3) && isfield(info,'Colorkey'), obj.ID(idx) = mgladdbitmap(bits,info.Colorkey); else obj.ID(idx) = mgladdbitmap(bits); end
                                    obj.Modality(idx) = 1;
                                    info = copyfield(obj,info,imfinfo(imdata));
                                    info.Size = mglgetproperty(obj.ID(idx),'size');
                                case {'.avi','.mpg','.mpeg'}
                                    obj.ID(idx) = mgladdmovie(imdata);
                                    obj.Modality(idx) = 2;
                                    info.Filename = imdata;
                                    info = copyfield(obj,info,mglgetproperty(obj.ID(idx),'info'));
                                otherwise
                                    error('Unknown file type from Gen');
                            end
                        else
                            info.Filename = '';
                            switch ndims(imdata)
                                case 2
                                    if isfield(info,'Colorkey'), obj.ID(idx) = mgladdbitmap(repmat(imdata,1,1,3),info.Colorkey); else obj.ID(idx) = mgladdbitmap(repmat(imdata,1,1,3)); end
                                    obj.Modality(idx) = 1;
                                    info.Size = mglgetproperty(obj.ID(idx),'size');
                                case 3,
                                    if 3==size(imdata,3) && isfield(info,'Colorkey'), obj.ID(idx) = mgladdbitmap(imdata,info.Colorkey); else obj.ID(idx) = mgladdbitmap(imdata); end
                                    obj.Modality(idx) = 1;
                                    info.Size = mglgetproperty(obj.ID(idx),'size');
                                case 4
                                    if isfield(info,'FramesPerSecond'), obj.ID(idx) = mgladdmovie(imdata,info.FramesPerSecond); else obj.ID(idx) = mgladdmovie(imdata,0.033333333333333333333333333333333); end
                                    obj.Modality(idx) = 2;
                                    info = copyfield(obj,info,mglgetproperty(obj.ID(idx),'info'));
                                otherwise, error('Image type from Gen cannot be determined');
                            end
                        end
                        obj.Position(idx,:) = [x y];
                        obj.MoreInfo{idx} = info;
                    case {'fix','dot'}
                        obj.ID(idx) = mgladdbitmap(load_cursor(MLConfig.FixationPointImage,MLConfig.FixationPointShape,MLConfig.FixationPointColor,MLConfig.PixelsPerDegree(1)*MLConfig.FixationPointDeg));
                        obj.Modality(idx) = 1;
                        obj.Position(idx,:) = [a{2:3}];
                        if isempty(MLConfig.FixationPointImage), obj.MoreInfo{idx}.Filename = ''; else obj.MoreInfo{idx} = imfinfo(MLConfig.FixationPointImage); end
                        obj.MoreInfo{idx}.Size = mglgetproperty(obj.ID(idx),'size');
                    case 'pic'
                        if 5<length(a), imdata = imresize(mglimread(a{2}),[a{6} a{5}],'lanczos3'); else imdata = mglimread(a{2}); end
                        if 3==size(imdata,3) && 3==length(a{end}), obj.ID(idx) = mgladdbitmap(imdata,a{end}); else obj.ID(idx) = mgladdbitmap(imdata); end
                        obj.Modality(idx) = 1;
                        obj.Position(idx,:) = [a{3:4}];
                        obj.MoreInfo{idx} = imfinfo(a{2});
                        obj.MoreInfo{idx}.Size = mglgetproperty(obj.ID(idx),'size');
                    case 'crc'
                        obj.ID(idx) = mgladdbitmap(make_circle(MLConfig.PixelsPerDegree(1)*a{2},a{3},a{4}));
                        obj.Modality(idx) = 1;
                        obj.Position(idx,:) = [a{5:6}];
                        obj.MoreInfo{idx}.Filename = '';
                        obj.MoreInfo{idx}.Size = mglgetproperty(obj.ID(idx),'size');
                    case 'sqr'
                        obj.ID(idx) = mgladdbitmap(make_rectangle(MLConfig.PixelsPerDegree(1)*a{2},a{3},a{4}));
                        obj.Modality(idx) = 1;
                        obj.Position(idx,:) = [a{5:6}];
                        obj.MoreInfo{idx}.Filename = '';
                        obj.MoreInfo{idx}.Size = mglgetproperty(obj.ID(idx),'size');
                    case 'mov'
                        obj.ID(idx) = mgladdmovie(a{2});
                        obj.Modality(idx) = 2;
                        obj.Position(idx,:) = [a{3:4}];
                        obj.MoreInfo{idx}.Filename = a{2};
                        obj.MoreInfo{idx} = copyfield(obj,obj.MoreInfo{idx},mglgetproperty(obj.ID(idx),'info'));
                    case 'snd'
                        [y,fs] = load_waveform(a);
                        obj.ID(idx) = mgladdsound(y,fs);
                        obj.Modality(idx) = 3;
                        if 2==length(a)
                            obj.MoreInfo{idx}.Filename = a{2};
                        else
                            obj.MoreInfo{idx}.Filename = '';
                        end
                        obj.MoreInfo{idx}.Duration = length(y)/fs;
                        obj.MoreInfo{idx}.Frequency = fs;
                    case 'stm'
                        obj.ID(idx) = a{2};
                        obj.Modality(idx) = 4;
                        [y,fs] = load_waveform(a{3});
                        obj.MoreInfo{idx}.Filename = a{3};
                        obj.MoreInfo{idx}.Channel = a{2};
                        obj.MoreInfo{idx}.Duration = length(y)/fs;
                        obj.MoreInfo{idx}.Frequency = fs;
                        o = MLConfig.DAQ.Stimulation{a{2}};
                        if isempty(o)
                            if ~TrialRecord.SimulationMode, error('''Stimulation %d'' is not assigned',a{2}); end
                        else
                            stop(o);
                            actual_rate = setverify(o,'SampleRate',fs);
                            if actual_rate~=fs, error('output frequency is %g kHz, instead of %g kHz',actual_rate/1000,fs/1000); end
                            ch = strcmp(o.Channel.ChannelName,sprintf('Stimulation%d',a{2}));
                            data = zeros(length(y),length(o.Channel));
                            data(:,ch) = y;
                            o.RegenerationMode = a{4};
                            putdata(o,data);
                            start(o);
                        end
                    case 'ttl'
                        obj.ID(idx) = a{2};
                        obj.Modality(idx) = 5;
                        obj.MoreInfo{idx}.Filename = '';
                        obj.MoreInfo{idx}.Channel = a{2};
                        if isempty(MLConfig.DAQ.TTL{a{2}}) && ~TrialRecord.SimulationMode, error('''TTL %d'' is not assigned',a{2}); end
                end
            end
            obj.ScreenPosition = get_ScreenPosition(obj,obj.Position);
            visualobj = 1==obj.Modality | 2==obj.Modality;
            mglsetorigin(obj.ID(visualobj),obj.ScreenPosition(visualobj,:));
        end
        
        function dest = copyfield(~,dest,src,field)
            if ~exist('field','var') || isempty(field), field = fieldnames(src); end
            for m=1:length(field), dest.(field{m}) = src.(field{m}); end
        end
    end
end
