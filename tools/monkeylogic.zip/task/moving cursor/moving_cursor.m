% This task draws a fixation point on the current mouse position.
%
%   Oct 17, 2016            Written by Jaewon Hwang (jaewon.hwang@nih.gov)

dashboard(1,'Press ''ESC'' to quit');

toggleobject(1,'status','on');

tic;
while toc < 10
    [xy,button] = mouse_position();
    reposition_object(1,xy);
    idle(1);
end
toggleobject(1,'status','off');
