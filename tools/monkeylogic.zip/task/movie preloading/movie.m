dashboard(1,TrialRecord.User.PreloadStatus);

toggleobject(1:4);
idle(1000);
